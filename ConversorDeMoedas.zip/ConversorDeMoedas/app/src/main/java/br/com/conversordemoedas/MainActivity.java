package br.com.conversordemoedas;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.view.View;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private EditText editQtdDolar;
    private EditText editCotacaoDolar;
    private TextView textResultado;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editQtdDolar = findViewById(R.id.editQtdDolar);
        editCotacaoDolar = findViewById(R.id.editCotacaoDolar);
        textResultado = findViewById(R.id.textResult);

    }

    public void converter(View view) {
        double qtdDolar = Double.parseDouble(editQtdDolar.getText().toString());
        double cotacaoDolar = Double.parseDouble(editCotacaoDolar.getText().toString());

        double resultado = qtdDolar * cotacaoDolar;

        textResultado.setText("O valor US$ " + qtdDolar + " corresponde a R$ " + resultado);
    }
}